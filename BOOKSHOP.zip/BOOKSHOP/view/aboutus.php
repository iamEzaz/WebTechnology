<!DOCTYPE html>
<html>
<head>
	<title>About Us |BOOKSHOP </title>
	<meta charset="UTF-8">

	<meta name="viewport" content="width-device-width, initial scale = 1.0">

	<script src = "https://code.jquery.com/jquery-2.1.3.min.js"></script>

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>

	  <link rel="stylesheet" href="A.assets,,_royalslider,,_royalslider.css+assets,,_royalslider,,_skins,,_default,,_rs-default.css+assets,,_royalslider,,_skins,,_minimal-white,,_rs-minimal-white.css+css,,_bootstrap.min.css+css,,_normalize.css+css,,_jquery-ui.css,Mcc.y-DhrddGnN.css.pagespeed.cf.Hfy0poW2iH.css"/>


	<link rel="stylesheet" href="style2.css">



</head>
<body>
	<?php
 include('homehead.php');
	?>


	
	<h1> <b>ABOUT US<b></h1>
        <div class="row img-row">

	       	   

        </div>
		<p>
</div>

<section>
	<div class="container opening">
		<div class="row about-row">
		<div class="col-lg-3 col-md-2 col-sm-3 img">
			<div class="container opening-hours">
				<h2><b>OPENING HOURS</b></h2>
				<p>Saturday to Thursday: 9am to 11pm</p>
				
				<p>Contact Number:01830773477</p>
				<p>Email:bookshop71@gmail.com</p>
		</div>
	</div>

		<div class="col-lg-3 col-md-4 col-sm-6 img">
			<img src="background/image4.jpg">
		</div>

</div>
</div>
</section>


<section>
	<div class="container featured-brands">
                <h2>FEATURED BRANDS</h2>
                <div class="row brands-logo">
					<div class="col-lg-4 col-md-6 col-sm-8">
						<a href="#"><img src="assets/plogo1.png"></a>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-8">
						<a href="#"><img src="assets/plogo2.gif"></a>
					</div>
						<div class="col-lg-6 col-md-3 col-sm-6">
						<a href="#"><img src="assets/plogo3.jpg">
						</a>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-8">
					<a href="#">	<img src="assets/plogo4.png">
					</a>
				    </div>
					
				</div>
</div>

</section>



</body>

<?php
include('includes/footer.php');
 ?>
