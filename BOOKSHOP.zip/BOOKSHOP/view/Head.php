<h1>

<p style="text-align:right;"><a class="" href="seller_home.php">Home</a> | <a class="" href="logout.php">Logout</a> |<a class="" href="Registrationform.php">Registration</a>   </p>
<img src="bookshoplogo.JPG" alt="" width="240" height="200">
</h1>


<?php 
	$var = 20;
 ?>