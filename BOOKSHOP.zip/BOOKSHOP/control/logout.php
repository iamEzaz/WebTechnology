<!-- <?php
session_start();

if(session_destroy()) // Destroying All Sessions
{
header("Location: ../view/login.php"); // Redirecting To Home Page
}
?> -->


<?php
session_start();
session_destroy();
setcookie('rememberMe', 'true',  time()-180, '/');
setcookie('Valid', 'true',  time()-60, '/');
header('location:../view/login.php');  //Redirecting to login page.
?>