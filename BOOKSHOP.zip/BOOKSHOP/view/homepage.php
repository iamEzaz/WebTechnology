
<!DOCTYPE html>
<html>
<head>
		<title>Home | BOOKSHOP</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width-device-width, initial scale = 1.0">
		<script src = "https://code.jquery.com/jquery-2.1.3.min.js"></script>

		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
	

		<link rel="stylesheet" href="style1.css">
    <link rel="stylesheet" href="style.css">


</head>


<body>
   <?php
	include('homehead.php');
	 ?> 


	<section class="home">
     <div class="slider">
      
        <div id class="slide active img-responsive" style="background-image: url('background/image11.jpg')">
            <div class="container">
                <div class="caption">
                
                </div>
            </div>
        </div>
    
     </div>

    <!-- controls  -->
    <div class="controls">
        <div class="prev"><</div>
        <div class="next">></div>
    </div>

    <!-- indicators -->
    <div class="indicator">
    </div>

  </section>


 <script src="script1.js"></script>


<style type="text/css">h2{color: #ffff;}</style>

<div class="header" style="color:#329FB1;padding: 30px">
	<h1 > <b>WELCOME TO BOOKSHOP<b></h1>
		<p style="color:#C0B7B4;">BOOKSHOP is a premium shop  that aims to serve those who truly appreciate premium collection of books. We primarily collect all kinds of books of the all decades. Working closely with some of the biggest bookshop of the world, we offer the best selection. We also have the necessary pdf, word files and software support.</p>
</div>
<style type="text/css">h2{color: #ffff;}</style>
<section id="home-featured">
 <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <img class="featured-icon" src="assets/featured logo.png" alt="Featured Icon">
                <h1 class="title"><b>FEATURED</b></h1>


								<div class="row book">
					<div id="rowbook" class="carousel slide w-10" data-ride="carousel" >
							<div class="carousel-inner w-10" role="listbox">
									<div class="carousel-item active">
											<div class="col-lg-4 col-md-6">
													<img class="img-fluid" src="bookpics/book1.jpg">
													<a href="">The Culprits</a>
											</div>
									</div>
									<div class="carousel-item">
											<div class="col-lg-4 col-md-6">
													<img class="img-fluid" src="bookpics/book2.jpg">
													<a href="">Bela Furaber Aghe</a>
											</div>
									</div> 
									<div class="carousel-item">
											<div class="col-lg-4 col-md-6">
													<img class="img-fluid" src="bookpics/book6.png">
													<a href="">The Mejesties</a>
											</div>
									</div> 
									<div class="carousel-item">
											<div class="col-lg-4 col-md-6">
													<img class="img-fluid" src="bookpics/book3.jpg">
													<a href="">TURBULENCE</a>
											</div>
									</div>
									<div class="carousel-item">
											<div class="col-lg-4 col-md-6">
													<img class="img-fluid" src="bookpics/book5.jpg">
													<a href="">Koilasher Kelenkari</a>
											</div>
									</div>
							</div>
							<a class="carousel-control-prev bg-dark w-auto" href="#myCarousel" role="button" data-slide="prev">
									<span class="carousel-control-prev-icon" aria-hidden="true"></span>

							</a>
							<a class="carousel-control-next bg-dark w-auto" href="#myCarousel" role="button" data-slide="next">
									<span class="carousel-control-next-icon" aria-hidden="true"></span>

							</a>
					</div>
			</div>




<div class="container">
    <div id="home-keys" class="row">
        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12" style="padding: 10px">
            <div class="keys-item">
                <a href="#">Stock</a>
            </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12" style="padding: 10px">
            <div class="keys-item reviews">
                <a href="#">CUSTOMER REVIEWS</a>
            </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12" style="padding: 10px">
            <div class="keys-item donation">
                <a href="#">Donation</a>
            </div>
        </div>
       
    </div>
</div>



	<!--scripts loaded here-->
	<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->
	<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script> -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<script src="carousel.js"></script>




            </div>
        </div>
    </div>
</section>
<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script> -->
    </body>



    <?php
    include('footer.php');
     ?>
